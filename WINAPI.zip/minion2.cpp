#include "stdafx.h"
#include "minion2.h"


minion2::minion2()
{
}


minion2::~minion2()
{
}
