#pragma once
#include "gameNode.h"
#include "saveLoadTest.h"


class playGround : public gameNode
{
private:
	saveLoadTest* _slt;





public:
	virtual HRESULT init();
	virtual void release();
	virtual void update();
	virtual void render();
	

	playGround();
	~playGround();
};

